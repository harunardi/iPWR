#!/bin/csh
#
##################################################################
#
#  <<  run COREBN  >>   
# 
##################################################################
#  CRBNgo : Execute COREBN (2 tahun kedua)
##################################################################
#
# Fortran logical unit usage for COREBN
#
#       [ ]:important files for users. 
# 
#   1   binary    scratch unit
#   2   binary    scratch unit
#   3   binary    scratch unit
# [ 5]  text:80   standard input
# [ 6]  text:137  standard output, message from COREBN
# [ 9]  binary    flux map file by option
#  10   binary    scratch unit
#  11   binary    scratch unit
# [13]  binary    restart file(with 98th file) for CITATION by option
#  14   binary    scratch unit
#  15   binary    scratch unit for equation constants
#                 high speed I/O unit is effective if possible
#  16   binary    scratch unit
#  18   binary    scratch unit
#  19   binary    scratch unit
#  26   binary    scratch unit
#  31   text:80   scratch unit
# [32]  binary    power density map file by option
#  50   text:80   scratch unit
#  89   binary    scratch unit
# [90]  binary    PS converted MACRO PDS file (read only)
#  91   text:80   scratch unit
# [92]  binary    old history file to be read (read only)
# [93]  binary    new history file to be written
#  94   text:80   scratch unit
#  95   text:80   scratch unit
#  96   binary    scratch unit
#  97   binary    scratch unit
# [98]  binary    restart file(with 13th file) for COREBN by option
# [99]  text:137  calculated results
#
#===============================================================================
#
   alias  mkdir mkdir
   alias  cat   cat
   alias  rm    rm
   alias  cd    cd
# 
#=============  Set by user ====================================================
#
#  LMN    : load module name of COREBN
#  ODR    : directory name in which all output data will be stored
#  HTO    : directory and file name of old history (read only)
#  HTN    : directory and file name of new history 
#  PSX    : directory and file name of PS converted MACRO (read only)
#  CASE   : case name which is refered as names of output files
#  WKDR   : directory name in which scratch PS files will be made and deleted
#
   set HOME = E:/SRAC2006/home/harunardi
   set CRBN_DIR = $HOME/COREBN
   set IO_DIR = $HOME/SKRIPSI/ftc4
   set LMN  = CRBN.100m
   set ODR  = $IO_DIR/outp
   set HTO  = $ODR/HIST.EO1C
   set HTN  = $ODR/HIST.EO2C
   set PSX  = $IO_DIR/macroPS.dat
   set CASE = CRBNgo02
#
#=============  Change if you like =============================================
#
   set LM   = $CRBN_DIR/bin/$LMN
   set DATE = `date +%Y.%m.%d.%H.%M.%S`
   set WKDR = $HOME/CRBNtmp.$CASE.$DATE
   mkdir $WKDR
#
   set OUTLST =  $ODR/$CASE.$DATE.CFT06
   setenv  fu99  $ODR/$CASE.$DATE.CFT99
   setenv  fu90  $PSX
   setenv  fu92  $HTO
   setenv  fu93  $HTN
#  setenv  fu09  $ODR/$CASE.FLUX.dat
#  setenv  fu32  $ODR/$CASE.POWR.dat
#  setenv  fu13  $ODR/$CASE.REST1.dat
#  setenv  fu98  $ODR/$CASE.REST2.dat
#
#=============  Exec COREBN code with the following input data =================
#
cd $WKDR
cat - << END_DATA | $LM >& $OUTLST
*--------1---------2---------3---------4---------5---------6---------7--
** Control data ********************************************************
3-D X-Y-Z Integral PWR Benchmark Full Core Burnup Calculation
Cycle No. : 1
1  1 37  0  24  020101  040101  0  0  4  1  0  1  1  772.039  557.039
0 11(720) 846 11(720) 846            /  Block-3 : Period (hour) 8766 1 4383 1/2 2922 1/3
25(160.0)             /  Block-4 : Power (MWt)
** Loading of fuel elements ********************************************
FUE1-001    6  6   3  3   1      -1    0   0  /  Block-5-1
FUE1-002    5  5   4  4   1      -1    0   0  
FUE1-003    6  6   4  4   1      -1    0   0  
FUE1-004    7  7   4  4   1      -1    0   0  
FUE1-005    3  3   5  5   1      -1    0   0  
FUE1-006    4  4   5  5   1      -1    0   0  
FUE1-007    6  6   5  5   1      -1    0   0  
FUE1-008    8  8   5  5   1      -1    0   0  
FUE1-009    9  9   5  5   1      -1    0   0  
FUE1-010    4  4   6  6   1      -1    0   0  
FUE1-011    5  5   6  6   1      -1    0   0  
FUE1-012    6  6   6  6   1      -1    0   0  
FUE1-013    7  7   6  6   1      -1    0   0  
FUE1-014    8  8   6  6   1      -1    0   0  
FUE1-015    3  3   7  7   1      -1    0   0  
FUE1-016    4  4   7  7   1      -1    0   0  
FUE1-017    6  6   7  7   1      -1    0   0  
FUE1-018    8  8   7  7   1      -1    0   0  
FUE1-019    9  9   7  7   1      -1    0   0  
FUE1-020    5  5   8  8   1      -1    0   0  
FUE1-021    6  6   8  8   1      -1    0   0  
FUE1-022    7  7   8  8   1      -1    0   0  
FUE1-023    6  6   9  9   1      -1    0   0  
FUE2-001    5  5   3  3   1      -1    0   0  
FUE2-002    7  7   3  3   1      -1    0   0  
FUE2-003    4  4   4  4   1      -1    0   0  
FUE2-004    8  8   4  4   1      -1    0   0  
FUE2-005    5  5   5  5   1      -1    0   0  
FUE2-006    7  7   5  5   1      -1    0   0  
FUE2-007    3  3   6  6   1      -1    0   0  
FUE2-008    9  9   6  6   1      -1    0   0  
FUE2-009    5  5   7  7   1      -1    0   0  
FUE2-010    7  7   7  7   1      -1    0   0  
FUE2-011    4  4   8  8   1      -1    0   0  
FUE2-012    8  8   8  8   1      -1    0   0  
FUE2-013    5  5   9  9   1      -1    0   0  
FUE2-014    7  7   9  9   1      -1    0   0  
** loading of non-fuel elements ****************************************
MODEA0C0            /  Block-7-1 : Background Material coolant
REFL-TOP          
  2 10   2  2    1
  2  4   3  3    1
  8 10   3  3    1
  2  3   4  4    1
  9 10   4  4    1
  2  2   5  7    1
 10 10   5  7    1
  2  3   8  8    1
  9 10   8  8    1
  2  4   9  9    1
  8 10   9  9    1
  2 10  10 10    1
  0  0   0  0    0
REFLCORE            /  Block-7-2  
  1 11   1  1    1  /  Block-7-3
  1  1   2  2    1
 11 11   2  2    1
  1  1   3  3    1
 11 11   3  3    1
  1  1   4  4    1
 11 11   4  4    1
  1  1   5  5    1
 11 11   5  5    1
  1  1   6  6    1
 11 11   6  6    1
  1  1   7  7    1
 11 11   7  7    1
  1  1   8  8    1
 11 11   8  8    1
  1  1   9  9    1
 11 11   9  9    1
  1  1  10 10    1
 11 11  10 10    1
  1 11  11 11    1
  0  0   0  0    0  /  End of Block-7-3 
REFL-BOT
  2 10   2  2   -6
  2  4   3  3   -6
  8 10   3  3   -6
  2  3   4  4   -6
  9 10   4  4   -6
  2  2   5  7   -6
 10 10   5  7   -6
  2  3   8  8   -6
  9 10   8  8   -6
  2  4   9  9   -6
  8 10   9  9   -6
  2 10  10 10   -6
  0  0   0  0    0
                    /  End of Block-7 
** Input for CITATION **************************************************
*-1--2--3--4--5--6--7--8--9-10-11-12-13-14-15-16-17-18-19-20-21-22-23-24
001* NGC IEDG ITMX GLIM
  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  1  0  0  0  0  0
  1  0  0  0  0  0  0  0  1  0  0  0  1  0  0  0  0  0  0  0  0  0  0  1
900  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0300  0  0  0  0  0  0
*-1-------E9--2-------E9--3-------E9--4-------E9--5-------E9--6-------E9
         1.5       0.001         0.0         0.0         0.0         0.0
003* NUAC EPSI XMIS
  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  0  1  0
      0.001     0.0001         0.0         0.0         0.0         0.0
* Flux and power density are normalized to core power : XXX0MWt*full core 
         0.0         0.0      160.0          1.0         1.0         0.0
999
END_DATA
#
#========  Remove scratch PS files =============================================
#
   cd $HOME
   rm -r $WKDR
