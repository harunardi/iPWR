#!/bin/csh
#
##################################################################
#                                 
#  <<  run SRAC  >> 
##################################################################
#  make macro XS(4g) for COREBN sample calculations (U3)
#  varfuel8burnc.sh : Integral PWR Square Assembly MOX fuel with 16% Pu
#  Options     : Pij(Geometry type IGT=16)
#============= Set by user =====================================================
#
   alias   mkdir mkdir
   alias   cat   cat
   alias   cd    cd
   alias   rm    rm
#
#  LMN    : load module name
#  BRN    : burnup chain library data
#  ODR    : directory name in which output data will be stored 
#  CASE   : case name which is refered as names of output files and PDS
#  WKDR   : directory name in which scratch PS files will be made and deleted
#  PDSD   : directory name in which PDS files will be made
#
   set HOME = E:/SRAC2006/home/harunardi
   set SRAC_DIR = $HOME/SRAC
   set CRBN_DIR = $HOME/COREBN
   set IO_DIR = $HOME/SKRIPSI/crwbest25
   set LMN  = SRAC.100m
   set BRN  = u4cm6fp50bp16T
   set ODR  = $IO_DIR/outp
   set CASE = crw34best25
   set PDSD = $CRBN_DIR/tmp
   set MACRO = $IO_DIR/macroPDS
#
#=============  mkdir for PDS  =================================================
#
#  PDS_DIR : directory name of PDS files
#  PDS file names must be identical with those in input data
#
   set PDS_DIR = $PDSD/$CASE
   mkdir $PDS_DIR
   mkdir $PDS_DIR/UFAST
   mkdir $PDS_DIR/UTHERMAL
   mkdir $PDS_DIR/UMCROSS
   mkdir $PDS_DIR/MACROWRK
#  mkdir $MACRO
   mkdir $PDS_DIR/FLUX
   mkdir $PDS_DIR/MICREF
#  
#=============  Change if you like =============================================
#
   set LM       = $SRAC_DIR/bin/$LMN
   set DATE     = `date +%Y.%m.%d.%H.%M.%S`
   set WKDR     = $HOME/SRACtmp.$CASE.$DATE
   mkdir $WKDR
#
#-- File allocation
#  fu89 is used in any plot options, fu98 is used in the burnup option
#  Add other units if you would like to keep necessary files.
   setenv  fu50  $SRAC_DIR/lib/burnlibT/$BRN
   setenv  fu85  $SRAC_DIR/lib/kintab.dat
#  setenv  fu89  $ODR/$CASE.$DATE.SFT89
   setenv  fu98  $ODR/$CASE.$DATE.SFT98
   setenv  fu99  $ODR/$CASE.$DATE.SFT99
   set OUTLST =  $ODR/$CASE.$DATE.SFT06
#
#=============  Exec SRAC code with the following input data ===================
#
cd $WKDR
cat - << END_DATA | $LM >& $OUTLST
F387                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 87 / TITLE
1 1 1 1 0   1 4 0 -2 1   0 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
*- PDS files ------2---------3---------4---------5---------6---------7--
* Note : All input line must be written in 72 columns except comments
*        even when environmental variables are expanded.
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pfast   Old  File
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pthml   O    F
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pmcrs   O    F
$PDS_DIR/UFAST      Scratch  Core
$PDS_DIR/UTHERMAL   S        C
$PDS_DIR/UMCROSS    S        C
$PDS_DIR/MACROWRK   S        C
$MACRO              New      C
$PDS_DIR/FLUX       S        C
$PDS_DIR/MICREF     S        C
************************************************************************
62 45 7 3   / NEF NET NERF NERT; 107 Energy Group => 10 Group
62(1)       / NEGF
45(1)       / NEGT
6(9) 8      / NECF; Fast 7 Group
3(15)       / NECT; Thermal 3 Group

***** Input for PIJ (Collision Probability Method)
16 1255 19 6 1   0 11 11 81 0   2 0 6 10 14   1 45 0 / PIJ CONTROL
0 100 60 5 5 5 0   0.0001 0.00001 0.001 1.0 10. 0.8   / PIJ Block 2
9(15 15 15 15 15 15 15 15 15 17 18) &           / IRR T-S
  17 17 17 17 17 17 17 17 17 17 18 &
  18 18 18 18 18 18 18 18 18 18 18 &
  16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
20(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
16(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
 3(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 19 19 19 19 19 19 19 19 19 19 11 12 13 14 &
23(1 2 3 4 5 6 7 8 9 10 11 12 13 14)
1 1 1 1 1 1 1 1 1 1 2 3 3 3 4 4 5 4 6   / IRR R-T
1 1 1 1 1 1                             / IXR X-R
1 2 3 4 5 6                             / MAR M-R
0 8*1.25984 1*0.6299 1*0.04 1*0.0032   / RX
0 8*1.25984 1*0.6299 1*0.04 1*0.0032   / TY
9(1 2 3 4 5 6 7 8 9)                   / RPP
9(1) 9(2) 9(3) 9(4) 9(5) &             / IYP
9(6) 9(7) 9(8) 9(9)
81(0 0.01 0.045085 0.09017 0.135255 0.18034 0.225425 0.27051 0.315595 &
0.36068 0.405765 0.414102 0.43434 0.45466 0.47498)     / RDP

6  / NMAT
FU13A010 0 8 772.039 0.81153 0.0  / 1. FUEL 4.55% ENRICH
XU050000 2 0 1.493437E-04
XU080000 2 0 2.059284E-02
XPU80000 2 0 1.301101E-04
XPU90000 2 0 1.428382E-03
XPU00000 2 0 6.788352E-04
XPU10000 2 0 3.535600E-04
XPU20000 2 0 2.375923E-04
XO060000 2 0 9.428266E-02
GA13A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL13A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO13A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF13A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR13A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.068126E-02
XB010000 0 0 8.874338E-02
XC020000 0 0 2.735616E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton          
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F388                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 88 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU23A010 0 8 772.039 0.81153 0.0  / 1. FUEL 4.55% ENRICH
XU050000 2 0 1.493437E-04
XU080000 2 0 2.059284E-02
XPU80000 2 0 1.301101E-04
XPU90000 2 0 1.428382E-03
XPU00000 2 0 6.788352E-04
XPU10000 2 0 3.535600E-04
XPU20000 2 0 2.375923E-04
XO060000 2 0 9.428266E-02
GA23A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL23A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO23A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF23A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR23A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.068126E-02
XB010000 0 0 8.874338E-02
XC020000 0 0 2.735616E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F397                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 97 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU33A010 0 8 772.039 0.81153 0.0  / 1. FUEL 4.55% ENRICH
XU050000 2 0 1.493437E-04
XU080000 2 0 2.059284E-02
XPU80000 2 0 1.301101E-04
XPU90000 2 0 1.428382E-03
XPU00000 2 0 6.788352E-04
XPU10000 2 0 3.535600E-04
XPU20000 2 0 2.375923E-04
XO060000 2 0 9.428266E-02
GA33A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL33A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO33A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF33A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR33A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F398                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 98 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU43A010 0 8 772.039 0.81153 0.0  / 1. FUEL 4.55% ENRICH
XU050000 2 0 1.493437E-04
XU080000 2 0 2.059284E-02
XPU80000 2 0 1.301101E-04
XPU90000 2 0 1.428382E-03
XPU00000 2 0 6.788352E-04
XPU10000 2 0 3.535600E-04
XPU20000 2 0 2.375923E-04
XO060000 2 0 9.428266E-02
GA43A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL43A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO43A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF43A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR43A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F487                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 87 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU14A010 0 15 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.471992E-04
XU080000 2 0 2.029713E-02
XPU80000 2 0 1.282417E-04
XPU90000 2 0 1.407871E-03
XPU00000 2 0 6.690872E-04
XPU10000 2 0 3.484829E-04
XPU20000 2 0 2.341805E-04
XGD20000 2 0 7.399832E-07
XGD40000 2 0 8.065817E-06
XGD50000 2 0 5.475876E-05
XGD60000 2 0 7.573728E-05
XGD70000 2 0 5.790368E-05
XGD80000 2 0 9.190591E-05
XGD00000 2 0 8.088016E-05
XO060000 2 0 3.291356E-01
GA14A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL12A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO14A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF14A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR14A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02     
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F488                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 88 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU24A010 0 15 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.471992E-04
XU080000 2 0 2.029713E-02
XPU80000 2 0 1.282417E-04
XPU90000 2 0 1.407871E-03
XPU00000 2 0 6.690872E-04
XPU10000 2 0 3.484829E-04
XPU20000 2 0 2.341805E-04
XGD20000 2 0 7.399832E-07
XGD40000 2 0 8.065817E-06
XGD50000 2 0 5.475876E-05
XGD60000 2 0 7.573728E-05
XGD70000 2 0 5.790368E-05
XGD80000 2 0 9.190591E-05
XGD00000 2 0 8.088016E-05
XO060000 2 0 3.291356E-01
GA24A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL22A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO24A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF22A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR24A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F497                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 97 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU34A010 0 15 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.471992E-04
XU080000 2 0 2.029713E-02
XPU80000 2 0 1.282417E-04
XPU90000 2 0 1.407871E-03
XPU00000 2 0 6.690872E-04
XPU10000 2 0 3.484829E-04
XPU20000 2 0 2.341805E-04
XGD20000 2 0 7.399832E-07
XGD40000 2 0 8.065817E-06
XGD50000 2 0 5.475876E-05
XGD60000 2 0 7.573728E-05
XGD70000 2 0 5.790368E-05
XGD80000 2 0 9.190591E-05
XGD00000 2 0 8.088016E-05
XO060000 2 0 3.291356E-01
GA34A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL34A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO34A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF34A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR34A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F498                                                                / CASE NAME
Integral PWR MOX fuel with 16% Pu pin cell problem 98 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                          / GEOMETRICAL BUCKLING
6  / NMAT
FU44A010 0 15 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.471992E-04
XU080000 2 0 2.029713E-02
XPU80000 2 0 1.282417E-04
XPU90000 2 0 1.407871E-03
XPU00000 2 0 6.690872E-04
XPU10000 2 0 3.484829E-04
XPU20000 2 0 2.341805E-04
XGD20000 2 0 7.399832E-07
XGD40000 2 0 8.065817E-06
XGD50000 2 0 5.475876E-05
XGD60000 2 0 7.573728E-05
XGD70000 2 0 5.790368E-05
XGD80000 2 0 9.190591E-05
XGD00000 2 0 8.088016E-05
XO060000 2 0 3.291356E-01
GA44A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL42A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO44A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF42A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
CR44A060 0 3 645.572 0.81153 0.0  / 6. Control Rod
XB000000 0 0 2.06813E-02
XB010000 0 0 8.87434E-02
XC020000 0 0 2.73562E-02
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************

END_DATA
#========  Remove scratch files ================================================
   cd $HOME
   rm -r $WKDR
#========  Remove PDS files if you don't keep them =============================
   rm -r $PDS_DIR
#
#  rm -r $PDS_DIR/UFAST
#  rm -r $PDS_DIR/UTHERMAL
#  rm -r $PDS_DIR/UMCROSS
#  rm -r $PDS_DIR/MACROWRK
#  rm -r $PDS_DIR/MACRO
#  rm -r $PDS_DIR/FLUX
#  rm -r $PDS_DIR/MICREF