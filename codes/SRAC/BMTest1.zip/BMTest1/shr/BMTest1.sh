#!/bin/csh
#
##################################################################
#                                 
#  <<  run SRAC  >> 
##################################################################
#  make macro XS(4g) for COREBN sample calculations (U3)
#  BMBurnrev3.sh : Integral PWR Square Assembly UO2 and UO2 plus Gd2O3 Benchmark
#  Options     : Pij(Geometry type IGT=16)
#============= Set by user =====================================================
#
   alias   mkdir mkdir
   alias   cat   cat
   alias   cd    cd
   alias   rm    rm
#
#  LMN    : load module name
#  BRN    : burnup chain library data
#  ODR    : directory name in which output data will be stored 
#  CASE   : case name which is refered as names of output files and PDS
#  WKDR   : directory name in which scratch PS files will be made and deleted
#  PDSD   : directory name in which PDS files will be made
#
   set HOME = E:/SRAC2006/home/harunardi
   set SRAC_DIR = $HOME/SRAC
   set CRBN_DIR = $HOME/COREBN
   set IO_DIR = $HOME/SKRIPSI/BMTest1
   set LMN  = SRAC.100m
   set BRN  = u4cm6fp50bp16T
   set ODR  = $IO_DIR/outp
   set CASE = BMTest1
   set PDSD = $CRBN_DIR/tmp
   set MACRO = $IO_DIR/macroPDS
#
#=============  mkdir for PDS  =================================================
#
#  PDS_DIR : directory name of PDS files
#  PDS file names must be identical with those in input data
#
   set PDS_DIR = $PDSD/$CASE
   mkdir $PDS_DIR
   mkdir $PDS_DIR/UFAST
   mkdir $PDS_DIR/UTHERMAL
   mkdir $PDS_DIR/UMCROSS
   mkdir $PDS_DIR/MACROWRK
#  mkdir $MACRO
   mkdir $PDS_DIR/FLUX
   mkdir $PDS_DIR/MICREF
#  
#=============  Change if you like =============================================
#
   set LM       = $SRAC_DIR/bin/$LMN
   set DATE     = `date +%Y.%m.%d.%H.%M.%S`
   set WKDR     = $HOME/SRACtmp.$CASE.$DATE
   mkdir $WKDR
#
#-- File allocation
#  fu89 is used in any plot options, fu98 is used in the burnup option
#  Add other units if you would like to keep necessary files.
   setenv  fu50  $SRAC_DIR/lib/burnlibT/$BRN
   setenv  fu85  $SRAC_DIR/lib/kintab.dat
#  setenv  fu89  $ODR/$CASE.$DATE.SFT89
   setenv  fu98  $ODR/$CASE.$DATE.SFT98
   setenv  fu99  $ODR/$CASE.$DATE.SFT99
   set OUTLST =  $ODR/$CASE.$DATE.SFT06
#
#=============  Exec SRAC code with the following input data ===================
#
cd $WKDR
cat - << END_DATA | $LM >& $OUTLST
F187                                                                / CASE NAME
Integral PWR Benchmark with UO2 pin cell problem 87 / TITLE
1 1 1 1 0   1 4 0 -2 1   0 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
*- PDS files ------2---------3---------4---------5---------6---------7--
* Note : All input line must be written in 72 columns except comments
*        even when environmental variables are expanded.
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pfast   Old  File
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pthml   O    F
E:/SRAC2006/home/harunardi/SRACLIB-JDL33/pds/pmcrs   O    F
$PDS_DIR/UFAST      Scratch  Core
$PDS_DIR/UTHERMAL   S        C
$PDS_DIR/UMCROSS    S        C
$PDS_DIR/MACROWRK   S        C
$MACRO              New      C
$PDS_DIR/FLUX       S        C
$PDS_DIR/MICREF     S        C
************************************************************************
62 45 7 3   / NEF NET NERF NERT; 107 Energy Group => 10 Group
62(1)       / NEGF
45(1)       / NEGT
6(9) 8      / NECF; Fast 7 Group
3(15)       / NECT; Thermal 3 Group

***** Input for PIJ (Collision Probability Method)
16 1255 18 5 1   0 11 11 81 0   2 0 6 10 14   1 45 0 / PIJ CONTROL
0 100 60 5 5 5 0   0.0001 0.00001 0.001 1.0 10. 0.8   / PIJ Block 2
9(15 15 15 15 15 15 15 15 15 17 18) &           / IRR T-S
  17 17 17 17 17 17 17 17 17 17 18 &
  18 18 18 18 18 18 18 18 18 18 18 &
  16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
20(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
16(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 3(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
 2(1 2 3 4 5 6 7 8 9 10 11 12 13 14) &
 16 16 16 16 16 16 16 16 16 16 16 12 13 14 &
23(1 2 3 4 5 6 7 8 9 10 11 12 13 14)
1 1 1 1 1 1 1 1 1 1 2 3 3 3 4 4 5 4    / IRR R-T
1 1 1 1 1                              / IXR X-R
1 2 3 4 5                              / MAR M-R
0 8*1.25984 1*0.6299 1*0.04 1*0.0032   / RX
0 8*1.25984 1*0.6299 1*0.04 1*0.0032   / TY
9(1 2 3 4 5 6 7 8 9)                   / RPP
9(1) 9(2) 9(3) 9(4) 9(5) &             / IYP
9(6) 9(7) 9(8) 9(9)
81(0 0.01 0.045085 0.09017 0.135255 0.18034 0.225425 0.27051 0.315595 &
0.36068 0.405765 0.414102 0.43434 0.45466 0.47498)     / RDP
5  / NMAT
FU11A010 0 3 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH
XU050000 2 0 9.506925E-04
XU080000 2 0 2.252320E-02
XO060000 2 0 4.694778E-02
GA11A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL11A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO11A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF11A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F188                                                                / CASE NAME
Integral PWR Benchmark with UO2 pin cell problem 88 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU21A010 0 3 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH
XU050000 2 0 9.506925E-04
XU080000 2 0 2.252320E-02
XO060000 2 0 4.694778E-02
GA21A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL21A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO21A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF21A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F197                                                                / CASE NAME
Integral PWR Benchmark with UO2 pin cell problem 97 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU31A010 0 3 772.039 0.81153 0.0  / 1. FUEL 4.55% ENRICH
XU050000 2 0 9.506925E-04
XU080000 2 0 2.252320E-02
XO060000 2 0 4.694778E-02
GA31A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL31A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO31A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF31A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F198                                                                / CASE NAME
Integral PWR Benchmark with UO2 pin cell problem 98 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU41A010 0 3 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH
XU050000 2 0 9.506925E-04
XU080000 2 0 2.252320E-02
XO060000 2 0 4.694778E-02
GA41A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL41A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO41A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF41A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F287                                                                / CASE NAME
Integral PWR Benchmark with UO2 plus Gd2O3 pin cell problem 87 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
7  / NMAT
FU12A010 0 10 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.052835E-03
XU080000 2 0 2.208639E-02
XGD20000 2 0 7.370219E-07
XGD40000 2 0 8.033539E-06
XGD50000 2 0 5.453962E-05
XGD60000 2 0 7.543419E-05
XGD70000 2 0 5.767196E-05
XGD80000 2 0 9.153812E-05
XGD00000 2 0 8.055649E-05
XO060000 2 0 2.341561E-01
GA12A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL12A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO12A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF12A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
MODEA0C0 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
REFL00R0 0 2 557.039 51.93782383 0.0 / 6. REFLEKTOR PbO
XPBN0000 0 0 2.753419E-02
XO060000 0 0 2.126109E-03
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F288                                                                / CASE NAME
Integral PWR Benchmark with UO2 plus Gd2O3 pin cell problem 88 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU22A010 0 10 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.052835E-03
XU080000 2 0 2.208639E-02
XGD20000 2 0 7.370219E-07
XGD40000 2 0 8.033539E-06
XGD50000 2 0 5.453962E-05
XGD60000 2 0 7.543419E-05
XGD70000 2 0 5.767196E-05
XGD80000 2 0 9.153812E-05
XGD00000 2 0 8.055649E-05
XO060000 2 0 2.341561E-01
GA22A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL22A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO22A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF22A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F297                                                                / CASE NAME
Integral PWR Benchmark with UO2 plus Gd2O3 pin cell problem 97 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU32A010 0 10 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 5% Gd2O3
XU050000 2 0 1.052835E-03
XU080000 2 0 2.208639E-02
XGD20000 2 0 7.370219E-07
XGD40000 2 0 8.033539E-06
XGD50000 2 0 5.453962E-05
XGD60000 2 0 7.543419E-05
XGD70000 2 0 5.767196E-05
XGD80000 2 0 9.153812E-05
XGD00000 2 0 8.055649E-05
XO060000 2 0 2.341561E-01
GA32A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL32A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO32A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF32A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05         
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************
F298                                                                / CASE NAME
Integral PWR Benchmark with UO2 plus Gd2O3 pin cell problem 98 / TITLE
1 1 1 1 0   1 4 0 -2 1   1 0 0 0 1   0 1 0 0 1                      / SRAC CONTROL 
1.09655E-03                                                           / GEOMETRICAL BUCKLING
5  / NMAT
FU42A010 0 10 772.039 0.81153 0.0  / 1. FUEL 4.95% ENRICH with 0.79% Gd2O3
XU050000 2 0 1.052835E-03
XU080000 2 0 2.208639E-02
XGD20000 2 0 7.370219E-07
XGD40000 2 0 8.033539E-06
XGD50000 2 0 5.453962E-05
XGD60000 2 0 7.543419E-05
XGD70000 2 0 5.767196E-05
XGD80000 2 0 9.153812E-05
XGD00000 2 0 8.055649E-05
XO060000 2 0 2.341561E-01
GA42A020 0 1 739.2093537 0.01651 0.0  / 2. GAP HELIUM
XHE40000 0 0 1.358223E-03
CL42A030 0 5 645.5721697 0.12192 0.0  / 3. CLADDING/GUIDE TUBE/CR
XZRN0000 0 0 4.232497E-02
XSNN0000 0 0 6.465578E-04
XFEN0000 0 0 8.620771E-05
XCRN0000 0 0 4.310385E-05
XNIN0000 0 0 3.017270E-06
MO42A040 0 2 557.039 0.437917 0.0 / 4. MODERATOR AND COOLANT
XH01H000 0 0 5.035633E-02
XO060000 0 0 2.517816E-02
SF42A050 0 8 557.039 0.08 0.0 / 5. STRUKTUR FA
XFEN0000 0 0 5.85614E-02
XC020000 0 0 2.62627E-05
XCRN0000 0 0 1.75085E-02
XMN50000 0 0 1.75085E-03
XNIN0000 0 0 8.75423E-03
XP010000 0 0 3.93940E-05
XS0N0000 0 0 2.62627E-05
XSIN0000 0 0 8.75423E-04
****** Input for cell burn-up calculation
25 1 1 1 0  0 0 0 0 0  10(0)   / max 60 IBC : burnup control
* Power history is normalized to achieve exposure of sample fuel : GWd/t
25(0.011811024)    / Power (MW/cm)
* Exposure in unit : burn-up MWD/ton
1000   2000    3000    4000    5000  &
6000   8000    10000   12000   14000 &
16000  20000   24000   28000   32000 &
40000  48000   56000   64000   72000 &
80000  104000  128000  152000  176000 / MWD/ton
********************************************************************************

END_DATA
#========  Remove scratch files ================================================
   cd $HOME
   rm -r $WKDR
#========  Remove PDS files if you don't keep them =============================
   rm -r $PDS_DIR
#
#  rm -r $PDS_DIR/UFAST
#  rm -r $PDS_DIR/UTHERMAL
#  rm -r $PDS_DIR/UMCROSS
#  rm -r $PDS_DIR/MACROWRK
#  rm -r $PDS_DIR/MACRO
#  rm -r $PDS_DIR/FLUX
#  rm -r $PDS_DIR/MICREF